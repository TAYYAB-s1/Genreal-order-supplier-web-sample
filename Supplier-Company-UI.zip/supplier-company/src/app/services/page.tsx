import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import Link from "next/link";
import { ShoppingBag, Truck, Boxes, Brain, BarChart, Shield, Wrench, HeartHandshake } from "lucide-react";

export const metadata = {
  title: "Our Services | SupplyPro",
  description: "Discover our comprehensive supply chain solutions including procurement, logistics, inventory management, and consulting services.",
};

export default function ServicesPage() {
  const services = [
    {
      id: "procurement",
      icon: <ShoppingBag className="h-12 w-12 text-blue-500 mb-6" />,
      title: "Procurement Solutions",
      description: "Strategic sourcing and supplier management to optimize your purchasing processes and reduce costs.",
      features: [
        "Vendor evaluation and selection",
        "Contract negotiation and management",
        "Purchase order automation",
        "Supplier relationship management",
      ],
    },
    {
      id: "logistics",
      icon: <Truck className="h-12 w-12 text-blue-500 mb-6" />,
      title: "Logistics Management",
      description: "End-to-end logistics services to ensure efficient movement of goods throughout your supply chain.",
      features: [
        "Transportation planning and optimization",
        "Carrier selection and management",
        "Cross-docking services",
        "Last-mile delivery solutions",
      ],
    },
    {
      id: "inventory",
      icon: <Boxes className="h-12 w-12 text-blue-500 mb-6" />,
      title: "Inventory Optimization",
      description: "Advanced inventory management systems to reduce holding costs while maintaining optimal stock levels.",
      features: [
        "Demand forecasting and planning",
        "Safety stock optimization",
        "Warehouse management systems",
        "Inventory auditing and reconciliation",
      ],
    },
    {
      id: "consulting",
      icon: <Brain className="h-12 w-12 text-blue-500 mb-6" />,
      title: "Supply Chain Consulting",
      description: "Expert guidance to design, optimize, and transform your supply chain operations.",
      features: [
        "Supply chain network design",
        "Process improvement and optimization",
        "Risk assessment and mitigation",
        "Sustainability planning and implementation",
      ],
    },
  ];

  const additionalServices = [
    {
      icon: <BarChart className="h-6 w-6 text-blue-600" />,
      title: "Analytics & Reporting",
      description: "Data-driven insights to monitor performance and make informed decisions.",
    },
    {
      icon: <Shield className="h-6 w-6 text-blue-600" />,
      title: "Quality Assurance",
      description: "Comprehensive quality control to ensure products meet specifications.",
    },
    {
      icon: <Wrench className="h-6 w-6 text-blue-600" />,
      title: "Technology Integration",
      description: "Implementation of SCM software and digital transformation solutions.",
    },
    {
      icon: <HeartHandshake className="h-6 w-6 text-blue-600" />,
      title: "Customer Support",
      description: "Dedicated account management and responsive customer service.",
    },
  ];

  return (
    <>
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-900 to-blue-700 py-16 md:py-24 text-white">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Our Services</h1>
            <p className="text-xl mb-8">
              Comprehensive supply chain solutions tailored to your business needs.
            </p>
            <Link href="/contact">
              <Button size="lg" className="bg-white text-blue-700 hover:bg-gray-100">
                Request a Quote
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Core Services */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <h2 className="text-3xl font-bold mb-4">Core Supply Chain Services</h2>
            <p className="text-gray-700">
              Our end-to-end supply chain solutions help businesses optimize operations, reduce costs, and improve efficiency.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            {services.map((service) => (
              <div key={service.id} id={service.id} className="bg-white p-8 rounded-lg shadow-md border border-gray-100">
                {service.icon}
                <h3 className="text-2xl font-bold mb-4">{service.title}</h3>
                <p className="text-gray-700 mb-6">{service.description}</p>
                <h4 className="font-semibold text-lg mb-3">Key Features:</h4>
                <ul className="space-y-2 mb-6">
                  {service.features.map((feature, index) => (
                    <li key={index} className="flex items-center">
                      <span className="mr-2 text-blue-500">•</span>
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
                <Button variant="outline">Learn More</Button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Additional Services */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Additional Services</h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {additionalServices.map((service, index) => (
              <Card key={index}>
                <CardHeader>
                  <div className="bg-blue-50 p-3 w-fit rounded-lg mb-4">
                    {service.icon}
                  </div>
                  <CardTitle>{service.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">{service.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Industries */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Industries We Serve</h2>
            <p className="text-gray-700">
              We provide specialized supply chain solutions across various industries, adapting our services to meet each sector's unique requirements.
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            {[
              "Manufacturing",
              "Retail",
              "Healthcare",
              "Food & Beverage",
              "Electronics",
              "Automotive",
              "Consumer Goods",
              "Construction",
            ].map((industry, index) => (
              <div key={index} className="p-6 bg-blue-50 rounded-lg">
                <h3 className="font-bold text-lg text-blue-800">{industry}</h3>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-blue-600 py-16 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to Optimize Your Supply Chain?</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Contact us today to discuss your supply chain needs and discover how our services can benefit your business.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link href="/contact">
              <Button size="lg" className="bg-white text-blue-600 hover:bg-gray-100">
                Contact Us
              </Button>
            </Link>
            <Button size="lg" variant="outline" className="text-white border-white hover:bg-blue-700">
              <Link href="/about">Learn About Us</Link>
            </Button>
          </div>
        </div>
      </section>
    </>
  );
}
