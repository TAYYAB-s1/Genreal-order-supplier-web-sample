import { Separator } from "@/components/ui/separator";
import { MessageSquare, Clock, Users, Award, Building, GraduationCap, Truck } from "lucide-react";

export const metadata = {
  title: "About Us | SupplyPro",
  description: "Learn about our company, mission, values, and team at SupplyPro.",
};

export default function AboutPage() {
  return (
    <>
      {/* Hero Section */}
      <section className="bg-blue-50 py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">About SupplyPro</h1>
            <p className="text-xl text-gray-700 mb-8">
              Your trusted partner in optimizing supply chain operations since 2009.
            </p>
            <Separator className="max-w-md mx-auto" />
          </div>
        </div>
      </section>

      {/* Company Story */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-6">Our Story</h2>
              <p className="text-gray-700 mb-4">
                SupplyPro was founded in 2009 with a clear mission: to transform how businesses manage their supply chains. What started as a small consulting firm has grown into a comprehensive supply chain solutions provider with clients across multiple industries.
              </p>
              <p className="text-gray-700 mb-4">
                Our founder, Jane Smith, identified a critical gap in the market—businesses were struggling with inefficient supply chains that increased costs and reduced competitiveness. From those insights, SupplyPro was born.
              </p>
              <p className="text-gray-700">
                Today, we serve hundreds of clients across the globe, helping them streamline operations, reduce costs, and build resilient supply chains that can withstand market disruptions.
              </p>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-blue-50 p-6 rounded-lg">
                <Building className="h-10 w-10 text-blue-500 mb-4" />
                <h3 className="text-xl font-bold mb-2">15+ Years</h3>
                <p className="text-gray-600">Of industry experience</p>
              </div>
              <div className="bg-blue-50 p-6 rounded-lg">
                <Users className="h-10 w-10 text-blue-500 mb-4" />
                <h3 className="text-xl font-bold mb-2">200+</h3>
                <p className="text-gray-600">Satisfied clients</p>
              </div>
              <div className="bg-blue-50 p-6 rounded-lg">
                <Truck className="h-10 w-10 text-blue-500 mb-4" />
                <h3 className="text-xl font-bold mb-2">$500M+</h3>
                <p className="text-gray-600">In managed orders</p>
              </div>
              <div className="bg-blue-50 p-6 rounded-lg">
                <GraduationCap className="h-10 w-10 text-blue-500 mb-4" />
                <h3 className="text-xl font-bold mb-2">50+</h3>
                <p className="text-gray-600">Certified professionals</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Mission & Values */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <h2 className="text-3xl font-bold mb-6">Our Mission & Values</h2>
            <p className="text-gray-700">
              At SupplyPro, we're guided by a set of core principles that define how we operate and serve our clients.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-lg shadow-sm border border-gray-100">
              <div className="bg-blue-100 p-3 rounded-full w-fit mb-6">
                <MessageSquare className="h-6 w-6 text-blue-700" />
              </div>
              <h3 className="text-xl font-bold mb-3">Transparency</h3>
              <p className="text-gray-700">
                We believe in open communication and complete visibility into supply chain processes.
              </p>
            </div>

            <div className="bg-white p-8 rounded-lg shadow-sm border border-gray-100">
              <div className="bg-blue-100 p-3 rounded-full w-fit mb-6">
                <Award className="h-6 w-6 text-blue-700" />
              </div>
              <h3 className="text-xl font-bold mb-3">Excellence</h3>
              <p className="text-gray-700">
                We strive for excellence in everything we do, from client service to operational execution.
              </p>
            </div>

            <div className="bg-white p-8 rounded-lg shadow-sm border border-gray-100">
              <div className="bg-blue-100 p-3 rounded-full w-fit mb-6">
                <Clock className="h-6 w-6 text-blue-700" />
              </div>
              <h3 className="text-xl font-bold mb-3">Reliability</h3>
              <p className="text-gray-700">
                Our clients count on us to deliver results consistently and meet deadlines without fail.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Leadership Team */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <h2 className="text-3xl font-bold mb-6">Our Leadership Team</h2>
            <p className="text-gray-700">
              Meet the experienced professionals who guide our company's strategy and operations.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {[
              {
                name: "Jane Smith",
                title: "CEO & Founder",
                bio: "15+ years in supply chain management and operations.",
              },
              {
                name: "John Rodriguez",
                title: "Chief Operations Officer",
                bio: "Former logistics director with expertise in global distribution.",
              },
              {
                name: "Sarah Chen",
                title: "Chief Technology Officer",
                bio: "Led digital transformation for Fortune 500 supply chains.",
              },
              {
                name: "Michael Davis",
                title: "VP of Client Relations",
                bio: "Dedicated to creating exceptional client experiences.",
              },
            ].map((member, index) => (
              <div key={index} className="text-center">
                <div className="w-32 h-32 bg-gray-200 rounded-full mx-auto mb-4"></div>
                <h3 className="text-xl font-bold mb-1">{member.name}</h3>
                <p className="text-blue-600 mb-2">{member.title}</p>
                <p className="text-gray-600">{member.bio}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Partnerships & Certifications */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Our Certifications & Partnerships</h2>
          <div className="flex flex-wrap justify-center gap-8">
            {Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="bg-white p-6 rounded-lg shadow-sm border border-gray-100 w-40 h-20 flex items-center justify-center">
                <span className="text-gray-400 font-medium">Partner Logo</span>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
