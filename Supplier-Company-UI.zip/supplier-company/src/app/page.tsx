import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowRight, CheckCircle, TrendingUp, BarChart4, ShieldCheck } from "lucide-react";

export default function Home() {
  return (
    <>
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-blue-900 to-blue-700 py-20 md:py-32">
        <div className="container mx-auto px-4 text-center text-white">
          <h1 className="text-4xl md:text-6xl font-bold mb-6">
            Streamline Your Supply Chain Operations
          </h1>
          <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto">
            We provide comprehensive supply chain solutions to help your business reduce costs and increase efficiency.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Button size="lg" className="bg-white text-blue-700 hover:bg-gray-100">
              <Link href="/services">Our Services</Link>
            </Button>
            <Button size="lg" variant="outline" className="text-white border-white hover:bg-blue-800">
              <Link href="/contact">Contact Us</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Why Choose Us</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="border-t-4 border-t-blue-500">
              <CardHeader>
                <TrendingUp className="h-10 w-10 text-blue-500 mb-4" />
                <CardTitle>Enhanced Efficiency</CardTitle>
                <CardDescription>
                  Optimize your supply chain processes to reduce delays and increase operational efficiency.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="border-t-4 border-t-blue-500">
              <CardHeader>
                <BarChart4 className="h-10 w-10 text-blue-500 mb-4" />
                <CardTitle>Cost Reduction</CardTitle>
                <CardDescription>
                  Strategic procurement and inventory management to minimize costs and maximize profitability.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="border-t-4 border-t-blue-500">
              <CardHeader>
                <ShieldCheck className="h-10 w-10 text-blue-500 mb-4" />
                <CardTitle>Quality Assurance</CardTitle>
                <CardDescription>
                  Rigorous quality control measures to ensure only the best products reach your customers.
                </CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>
      </section>

      {/* Services Overview */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-6">Comprehensive Supply Solutions</h2>
              <p className="text-gray-700 mb-6">
                Our team of experts delivers end-to-end supply chain services tailored to your specific industry needs.
                From procurement to distribution, we've got you covered.
              </p>
              <ul className="space-y-4 mb-8">
                <li className="flex items-start">
                  <CheckCircle className="h-6 w-6 text-green-500 mr-2 flex-shrink-0" />
                  <span>Strategic procurement and vendor management</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-6 w-6 text-green-500 mr-2 flex-shrink-0" />
                  <span>Inventory optimization and warehouse management</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-6 w-6 text-green-500 mr-2 flex-shrink-0" />
                  <span>Logistics and distribution solutions</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-6 w-6 text-green-500 mr-2 flex-shrink-0" />
                  <span>Supply chain consulting and technology integration</span>
                </li>
              </ul>
              <Link href="/services" className="inline-flex items-center text-blue-600 font-medium hover:text-blue-800">
                Explore all services <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </div>
            <div className="bg-gray-100 p-8 rounded-lg">
              <h3 className="text-2xl font-bold mb-6">Request a Consultation</h3>
              <p className="text-gray-700 mb-6">
                Interested in learning how we can optimize your supply chain? Fill out the form below to schedule a free consultation with one of our experts.
              </p>
              <form className="space-y-4">
                <div>
                  <input
                    type="text"
                    placeholder="Company Name"
                    className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <input
                    type="email"
                    placeholder="Email Address"
                    className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <textarea
                    placeholder="Tell us about your supply chain needs"
                    rows={4}
                    className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  ></textarea>
                </div>
                <Button className="w-full">Submit Request</Button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-blue-600 py-16 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to Transform Your Supply Chain?</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Partner with SupplyPro and experience the difference our expertise can make for your business.
          </p>
          <Button size="lg" className="bg-white text-blue-600 hover:bg-gray-100">
            <Link href="/contact">Get Started Today</Link>
          </Button>
        </div>
      </section>
    </>
  );
}
